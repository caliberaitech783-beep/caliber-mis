import {spawn} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
export async function ensureConnectorRunning({directory=root,version='1.0.7',fetcher=fetch,spawnProcess=spawn,sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms)),attempts=30}={}){
 async function healthy(){
  let response;try{response=await fetcher('http://127.0.0.1:4174/api/health',{signal:AbortSignal.timeout(2000)})}catch{return false}
  let health;try{health=await response.json()}catch{throw Error('Port 4174 is being used by another program. Contact your administrator.')}
  if(!response.ok||health.service!=='caliber-scanner')throw Error('Port 4174 is being used by another program. Contact your administrator.');
  if(health.version!==version)throw Error('A different Caliber Scanner version is running. Finish scanning, restart Windows once, then sign in. The updated connector will start automatically.');
  return true;
 }
 if(await healthy())return {alreadyRunning:true};
 const child=spawnProcess(process.execPath,[path.join(directory,'connector.mjs')],{cwd:directory,windowsHide:true,detached:true,stdio:'ignore'});
 let launchError;child.on?.('error',error=>{launchError=error});child.unref();
 for(let n=0;n<attempts;n++){if(launchError)throw Error('Caliber Scanner could not start: '+launchError.message);await sleep(500);if(await healthy())return {alreadyRunning:false}}
 throw Error('Connector did not start. Open the Caliber Scanner shortcut to retry, or contact your administrator. Reinstallation is not required.');
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 try{await ensureConnectorRunning();console.log('Caliber Scanner is ready. Click Connect PC scanner in online MIS.')}catch(error){console.error(error.message);process.exitCode=1}
}

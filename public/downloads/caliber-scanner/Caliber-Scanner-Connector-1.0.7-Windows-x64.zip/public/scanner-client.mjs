import {compressScannerPage} from './scanner-compression.mjs';
import {organizationScanners,chooseConnectedScanner,scannerConnectionMessage} from './scanner-selection.mjs';
const ONLINE='https://pulse-ll.cmll.in',q=new URLSearchParams(location.hash.slice(1)),nonce=q.get('nonce'),kind=q.get('kind'),remote=window.opener;
const $=id=>document.getElementById(id),sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
let token='',busy=false,previousDevices,lastJob=null,ready=false;
function say(message){$('message').textContent=message;if(remote)remote.postMessage({type:'scanner-progress',nonce,message},ONLINE);}
function controls(){for(const id of ['scan','refresh','device','retry'])$(id).disabled=busy||!ready||(id==='scan'&&!$('device').value);}
async function api(route,data){const r=await fetch('/api/'+route,{method:data?'POST':'GET',headers:{'X-Caliber-Scanner':'1',Authorization:'Bearer '+token,...(data?{'Content-Type':'application/json'}:{})},...(data?{body:JSON.stringify(data)}:{})});const result=await r.json();if(!r.ok)throw Error(result.error||'Scanner connection failed.');return result;}
async function refresh(){const status=await api('local-scanner/status'),devices=organizationScanners(status.devices);const selected=chooseConnectedScanner(devices,$('device').value,previousDevices);$('device').replaceChildren(...devices.map(device=>{const option=document.createElement('option');option.value=device.id;option.textContent=device.name;return option;}));$('device').value=selected;previousDevices=devices.map(d=>d.id);controls();say(status.deviceError||scannerConnectionMessage(devices,selected));}
function sendPage(card,bytes,captureTiming){return new Promise((resolve,reject)=>{
 const receive=event=>{if(event.origin!==ONLINE||event.source!==remote||event.data?.nonce!==nonce||event.data?.type!=='scanner-ack'||event.data?.cardId!==card.id)return;cleanup();event.data.error?reject(Error(event.data.error)):resolve();};
 const timer=setTimeout(()=>{cleanup();reject(Error('Online MIS did not acknowledge this page. Keep MIS open, then retry sending.'));},120000);
 function cleanup(){clearTimeout(timer);window.removeEventListener('message',receive);}
 window.addEventListener('message',receive);try{remote.postMessage({type:'scanner-page',nonce,cardId:card.id,filename:card.filename,mimeType:card.mimeType||'image/png',bytes,captureTiming},ONLINE,[bytes]);}catch(error){cleanup();reject(error);}
});}
async function transfer(){const batch=await api('scan-batches/'+lastJob.batch_id);if(!batch.cards.length){say(lastJob.error||'No pages scanned. Load the feeder, then scan again.');return;}
 const captureTiming={mode:'scanner',pages:lastJob.pages,durationMs:Math.max(0,Date.parse(lastJob.completed_at)-Date.parse(lastJob.created_at))};
 for(const [index,card]of batch.cards.entries()){say(`Sending page ${index+1} of ${batch.cards.length}${card.sizeBytes?' ('+Math.ceil(card.sizeBytes/1000)+' KB)':''} to online MIS…`);const response=await fetch('/api/scan-cards/'+card.id+'/image',{headers:{'X-Caliber-Scanner':'1',Authorization:'Bearer '+token}});if(!response.ok)throw Error('Cannot read retained scanner page.');let uploadCard=card,bytes;const blob=await response.blob();const compressed=await compressScannerPage(blob);if(compressed.reused){bytes=await blob.arrayBuffer();}else{say('Compressing page '+(index+1)+' of '+batch.cards.length+'…');const saved=await fetch('/api/scan-cards/'+card.id+'/compressed',{method:'POST',headers:{'X-Caliber-Scanner':'1',Authorization:'Bearer '+token,'Content-Type':compressed.blob.type},body:compressed.blob});const result=await saved.json();if(!saved.ok)throw Error(result.error||'Cannot retain compressed copy.');uploadCard={...card,...result};bytes=await compressed.blob.arrayBuffer();}say('Sending page '+(index+1)+' of '+batch.cards.length+' ('+Math.ceil(bytes.byteLength/1000)+' KB) to online MIS…');await sendPage(uploadCard,bytes,captureTiming);}
 remote.postMessage({type:'scanner-complete',nonce,captureTiming},ONLINE);$('retry').hidden=true;
 say(lastJob.error?`Scanned pages sent. Scanner reported: ${lastJob.error}`:'All pages sent to online MIS. Complete, valid cards save automatically; correct any flagged values.');
 if(!lastJob.error){try{remote.focus();}catch{}window.close();}
}
async function run(task){if(busy||!ready)return;busy=true;controls();try{await task();}catch(error){say(error.message+' Any scanned pages are retained on this PC.');}finally{busy=false;controls();}}
$('scan').onclick=()=>void run(async()=>{const result=await api('local-scanner/capture',{kind,deviceId:$('device').value});$('retry').hidden=true;do{await sleep(1000);lastJob=await api('local-scanner/jobs/'+result.id);say(lastJob.pages+' page(s) scanned…');}while(lastJob.status==='running');$('retry').hidden=!lastJob.pages;await transfer();});
$('refresh').onclick=()=>void run(refresh);$('retry').onclick=()=>void run(transfer);
if(!remote||q.get('origin')!==ONLINE||!['vehicle','equipment'].includes(kind)||!/^[a-f0-9-]{36}$/i.test(nonce||'')||!/^[a-f0-9]{64}$/.test(q.get('ticket')||'')){
 $('message').textContent='Open online MIS, sign in and click Connect PC scanner to authorize scanning.';
}else{
 void(async()=>{try{const result=await api('scanner-connector/connect',{ticket:q.get('ticket'),nonce,kind});token=result.token;history.replaceState(null,'',location.pathname);ready=true;await refresh();const timer=setInterval(()=>{if(!busy)void refresh().catch(error=>{say(error.message);$('scan').disabled=true;});},5000);window.addEventListener('pagehide',()=>clearInterval(timer),{once:true});}catch(error){say(error.message);}})();
}

using System;
using System.IO;
using System.Collections.Generic;
using System.Web.Script.Serialization;
class WiaScanner {
 static JavaScriptSerializer serializer=new JavaScriptSerializer();
 static void Emit(object data){Console.WriteLine(serializer.Serialize(data));Console.Out.Flush();}
 static dynamic Property(dynamic target,int id){foreach(dynamic property in target.Properties)if((int)property.PropertyID==id)return property;return null;}
 static bool Empty(Exception error){while(error!=null){if(error.HResult==-2145320957)return true;error=error.InnerException;}return false;}
 static int Main(string[] args){try{
  Console.OutputEncoding=new System.Text.UTF8Encoding(false);
  string action=args.Length>0?args[0]:"list";
  dynamic manager=Activator.CreateInstance(Type.GetTypeFromProgID("WIA.DeviceManager",true));
  dynamic selected=null;var devices=new List<object>();
  foreach(dynamic info in manager.DeviceInfos){if((int)info.Type!=1)continue;string id=(string)info.DeviceID,name="";
   foreach(dynamic property in info.Properties)if((string)property.Name=="Name"){name=Convert.ToString(property.Value);break;}
   devices.Add(new {id=id,name=name});if(id==Environment.GetEnvironmentVariable("PULSE_SCANNER_DEVICE_ID"))selected=info;
  }
  if(action=="list"){Emit(new {devices=devices});return 0;}
  if(action!="capture")throw new Exception("Unknown scanner operation.");
  if(selected==null)throw new Exception("Selected scanner is not connected.");
  string directory=Path.GetFullPath(Environment.GetEnvironmentVariable("PULSE_SCANNER_JOB_DIR")??"");
  if(!Directory.Exists(directory))throw new Exception("Scanner output folder is unavailable.");
  dynamic device=selected.Connect(),capabilities=Property(device,3086);
  bool feeder=capabilities!=null&&(Convert.ToInt32(capabilities.Value)&1)!=0;
  dynamic source=Property(device,3088);if(source!=null)source.Value=feeder?1:2;
  dynamic pages=Property(device,3096);if(pages!=null)pages.Value=1;
  dynamic item=device.Items[1];
  // Cards are ink on paper: request grayscale (WIA_IPA_DATATYPE 2, else WIA_IPS_CUR_INTENT grayscale)
  // so each page transfers in a third of the bytes. Drivers that refuse keep colour; the connector converts.
  try{Property(item,4103).Value=2;}catch{try{Property(item,6146).Value=2;}catch{}}
  dynamic dpiX=Property(item,6147),dpiY=Property(item,6148),extentX=Property(item,6151),extentY=Property(item,6152);
  double physicalX=Convert.ToDouble(extentX.Value)/Convert.ToDouble(dpiX.Value),physicalY=Convert.ToDouble(extentY.Value)/Convert.ToDouble(dpiY.Value);
  try{dpiX.Value=300;}catch{}try{dpiY.Value=300;}catch{}
  extentX.Value=(int)(physicalX*Convert.ToDouble(dpiX.Value));extentY.Value=(int)(physicalY*Convert.ToDouble(dpiY.Value));
  int count=0,limit=feeder?40:1;
  while(count<limit){dynamic image;try{image=item.Transfer("{B96B3CAF-0728-11D3-9D7B-0000F81EF32E}");}catch(Exception error){if(Empty(error)){if(count==0){Emit(new {type="error",message="The feeder is empty. Load the cards and scan again."});return 2;}break;}throw;}
   count++;string filename="page-"+count.ToString("D3")+".png";image.SaveFile(Path.Combine(directory,filename));Emit(new {type="page",filename=filename,page=count});
  }
  Emit(new {type="complete",pages=count,limitReached=feeder&&count==limit});return 0;
 }catch(Exception error){Emit(new {type="error",message="Windows scanner: "+error.Message});return 1;}}
}

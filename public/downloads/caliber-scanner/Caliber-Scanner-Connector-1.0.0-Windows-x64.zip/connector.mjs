import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import {randomBytes,randomUUID} from 'node:crypto';
import {execFile,spawn} from 'node:child_process';
import {promisify} from 'node:util';
import {fileURLToPath} from 'node:url';
import {organizationScanners} from './public/scanner-selection.mjs';

export const VERSION='1.0.0';
const ONLINE='https://pulse-ll.cmll.in',LOCAL='http://127.0.0.1:4174';
const root=path.dirname(fileURLToPath(import.meta.url));
const scannerHelper=path.join(root,'scripts','WiaScanner.exe'),exec=promisify(execFile);
const fail=(message,status=400)=>Object.assign(new Error(message),{status});
const uuid=v=>/^[a-f0-9-]{36}$/i.test(v||'');
const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(data));};
async function body(req){let data='';for await(const chunk of req){data+=chunk;if(Buffer.byteLength(data)>8192)throw fail('Request is too large.',413);}try{return JSON.parse(data);}catch{throw fail('Invalid JSON.');}}
export async function listWindowsScanners(){
 const {stdout}=await exec(scannerHelper,['list'],{windowsHide:true,timeout:20000,maxBuffer:1024*1024});
 return organizationScanners(JSON.parse(stdout.replace(/^\uFEFF/, '')).devices||[]);
}
export function captureWindowsScanner(deviceId,directory,onPage){
 return new Promise((resolve,reject)=>{
  const proc=spawn(scannerHelper,['capture'],{windowsHide:true,env:{...process.env,PULSE_SCANNER_DEVICE_ID:deviceId,PULSE_SCANNER_JOB_DIR:directory},stdio:['ignore','pipe','pipe']});
  let buffer='',problem='',pending=Promise.resolve(),stderr='';
  const timer=setTimeout(()=>{problem='Scanning timed out. Check the scanner and feeder.';proc.kill();},30*60*1000);
  const line=text=>{try{const event=JSON.parse(text.replace(/^\uFEFF/,''));if(event.type==='error')problem=String(event.message);if(event.type==='page')pending=pending.then(()=>onPage(event)).catch(error=>{problem=error.message;proc.kill();});}catch{problem='Windows returned an invalid scanner response.';}};
  proc.stdout.on('data',chunk=>{buffer+=chunk.toString();let at;while((at=buffer.indexOf('\n'))!==-1){line(buffer.slice(0,at).trim());buffer=buffer.slice(at+1);}});
  proc.stderr.on('data',chunk=>{stderr=(stderr+chunk).slice(-1000);});
  proc.on('error',error=>{clearTimeout(timer);reject(error);});
  proc.on('close',async code=>{clearTimeout(timer);if(buffer.trim())line(buffer.trim());await pending;problem||code!==0?reject(Error(problem||stderr||'Windows scanner did not finish.')):resolve();});
 });
}
export function createConnector({listDevices=listWindowsScanners,capture=captureWindowsScanner,fetchOnline=fetch,stateRoot=path.join(process.env.LOCALAPPDATA||os.homedir(),'CaliberScanner','scans')}={}){
 const sessions=new Map(),jobs=new Map(),attempts=new Map();let active=null;
 const publicFiles={'/':'index.html','/scanner-connector.html':'scanner-connector.html','/scanner-client.mjs':'scanner-client.mjs','/scanner-selection.mjs':'scanner-selection.mjs'};
 const server=http.createServer(async(req,res)=>{try{
  if(!['127.0.0.1:4174','localhost:4174'].includes(req.headers.host))throw fail('Invalid local connector host.',403);
  const url=new URL(req.url,LOCAL),route=url.pathname;
  if(req.method==='GET'&&route==='/scanner-ready.txt'){res.writeHead(200,{'Content-Type':'text/plain','Cache-Control':'no-store'});res.end('caliber-pc-scanner-ready');return;}
  if(req.headers.origin&&req.headers.origin!==LOCAL)throw fail('Open the connector from online MIS.',403);
  if(req.method==='GET'&&route==='/api/health'){json(res,200,{status:'ok',service:'caliber-scanner',version:VERSION});return;}
  if(req.method==='GET'&&publicFiles[route]){const bytes=await fs.readFile(path.join(root,'public',publicFiles[route]));res.writeHead(200,{'Content-Type':route.endsWith('.mjs')?'text/javascript; charset=utf-8':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'"});res.end(bytes);return;}
  if(!route.startsWith('/api/'))throw fail('Not found.',404);
  if(req.headers['x-caliber-scanner']!=='1')throw fail('Use Connect PC scanner in online MIS.',403);
  for(const [key,session]of sessions)if(session.expires<Date.now())sessions.delete(key);
  if(req.method==='POST'&&route==='/api/scanner-connector/connect'){
   const data=await body(req);if(!/^[a-f0-9]{64}$/.test(data.ticket||'')||!uuid(data.nonce)||!['vehicle','equipment'].includes(data.kind))throw fail('Invalid scanner connection.');
   const now=Date.now();for(const [key,time]of attempts)if(time<now-60000)attempts.delete(key);if(attempts.size>=20)throw fail('Too many connection attempts. Wait a minute.',429);attempts.set(randomUUID(),now);
   let proof,response;try{response=await fetchOnline(ONLINE+'/api/scanner-connector/redeem',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data),signal:AbortSignal.timeout(15000)});proof=await response.json();}catch{throw fail('Cannot reach online MIS. Reconnect after checking the internet connection.',503);}
   if(!response.ok||!proof.authorized||proof.nonce!==data.nonce||proof.kind!==data.kind)throw fail('Connection expired. Close this window and reconnect from MIS.',401);
   const token=randomBytes(32).toString('hex');sessions.set(token,{kind:data.kind,expires:now+2*60*60*1000});json(res,200,{token});return;
  }
  const token=String(req.headers.authorization||'').replace(/^Bearer /,''),session=sessions.get(token);if(!session)throw fail('Reconnect using Connect PC scanner in online MIS.',401);
  if(req.method==='GET'&&route==='/api/local-scanner/status'){
   let devices=[],deviceError='';try{devices=organizationScanners(await listDevices());}catch{deviceError='Windows could not detect scanners. Check the WIA scanner driver and USB connection.';}
   json(res,200,{enabled:true,devices,deviceError,files:[],activeJob:active});return;
  }
  if(req.method==='POST'&&route==='/api/local-scanner/capture'){
   const data=await body(req);if(data.kind!==session.kind)throw fail('Wrong card type.',403);if(active)throw fail('Another scan is running.',409);
   active='starting';let device;try{device=organizationScanners(await listDevices()).find(d=>d.id===data.deviceId);}catch(error){active=null;throw error;}if(!device){active=null;throw fail('Select a connected Brother ADS-3100 or Canon DR-C225II.');}
   const id=randomUUID(),directory=path.join(stateRoot,id);try{await fs.mkdir(directory,{recursive:true});}catch(error){active=null;throw error;}
   const job={id,batch_id:id,status:'running',pages:0,mode:'scanner',created_at:new Date().toISOString(),completed_at:null,error:'',owner:token,directory,cards:[]};jobs.set(id,job);active=id;json(res,202,{id,batchId:id});
   void(async()=>{try{await capture(device.id,directory,async event=>{
    if(job.pages>=120||!/^page-\d{3}\.png$/.test(event.filename)||job.cards.some(card=>card.filename===event.filename))throw Error('Invalid scanner page.');
    const file=path.join(directory,event.filename),size=(await fs.stat(file)).size;if(size>12000000)throw Error('Scanner page exceeds 12 MB.');
    job.cards.push({id:randomUUID(),filename:event.filename,status:'review',file});job.pages++;
   });job.status='complete';}catch(error){job.status='error';job.error=error.message;}finally{job.completed_at=new Date().toISOString();active=null;await fs.writeFile(path.join(directory,'scan.json'),JSON.stringify({id:job.id,status:job.status,pages:job.pages,error:job.error,created_at:job.created_at,completed_at:job.completed_at})).catch(()=>{});}})();return;
  }
  let match;
  if(req.method==='GET'&&(match=route.match(/^\/api\/local-scanner\/jobs\/([a-f0-9-]{36})$/i))){const job=jobs.get(match[1]);if(!job||job.owner!==token)throw fail('Scan not found.',404);const {owner,directory,cards,...visible}=job;json(res,200,visible);return;}
  if(req.method==='GET'&&(match=route.match(/^\/api\/scan-batches\/([a-f0-9-]{36})$/i))){const job=jobs.get(match[1]);if(!job||job.owner!==token)throw fail('Scan not found.',404);json(res,200,{cards:job.cards.map(({file,...card})=>card)});return;}
  if(req.method==='GET'&&(match=route.match(/^\/api\/scan-cards\/([a-f0-9-]{36})\/image$/i))){let card;for(const job of jobs.values())if(job.owner===token){card=job.cards.find(c=>c.id===match[1]);if(card)break;}if(!card)throw fail('Page not found.',404);const bytes=await fs.readFile(card.file);res.writeHead(200,{'Content-Type':'image/png','Cache-Control':'no-store'});res.end(bytes);return;}
  throw fail('Operation unavailable in the standalone scanner connector.',404);
 }catch(error){if(!res.headersSent)json(res,error.status||500,{error:error.status?error.message:'The local scanner operation failed. Check the scanner and reconnect.'});else res.end();}});
 server.requestTimeout=30000;server.headersTimeout=15000;return server;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const server=createConnector();server.listen(4174,'127.0.0.1',()=>console.log('Caliber Scanner '+VERSION+' listening on '+LOCAL));
 server.on('error',error=>{console.error(error.code==='EADDRINUSE'?'Another local connector is already using port 4174.':error.message);process.exitCode=1;});
}

import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createInterface} from 'node:readline/promises';
import {execFile,spawn} from 'node:child_process';
import {promisify} from 'node:util';
const root=path.dirname(fileURLToPath(import.meta.url));
if(process.platform!=='win32'||process.arch!=='x64')throw Error('This installer requires 64-bit Windows.');
const base=path.join(process.env.LOCALAPPDATA,'CaliberScanner'),stamp=new Date().toISOString().replace(/[:.]/g,'-'),target=path.join(base,'versions','1.0.1-'+stamp);
console.log('Install Caliber Scanner for Brother ADS-3100 and Canon DR-C225II.');
console.log('Files: '+target+'\nCreates or updates Caliber Scanner shortcuts on your Desktop and Start Menu. Starts a connector accessible only on this PC at 127.0.0.1:4174.');
console.log('No administrator account, local MIS database, or separate Node.js installation is required. Scanner drivers must be installed separately.');
const prompt=createInterface({input:process.stdin,output:process.stdout});const answer=await prompt.question('Install and start? Type YES: ');prompt.close();if(answer!=='YES'){console.log('Installation cancelled; no changes made.');process.exit(0);}
await fs.mkdir(target,{recursive:true});await fs.cp(root,target,{recursive:true,errorOnExist:true,force:false});
const launcher=path.join(target,'Launch-Caliber-Scanner.vbs');
await fs.writeFile(launcher,'Set shell = CreateObject("WScript.Shell")\r\nshell.Run """'+path.join(target,'node.exe').replaceAll('"','""')+'"" ""'+path.join(target,'start.mjs').replaceAll('"','""')+'""", 0, False\r\n');
const quote=s=>"'"+s.replaceAll("'","''")+"'";
const powershell=path.join(process.env.SystemRoot,'System32','WindowsPowerShell','v1.0','powershell.exe');
const command=`$shell=New-Object -ComObject WScript.Shell; $locations=@($shell.SpecialFolders.Item('Desktop'),(Join-Path $env:APPDATA 'Microsoft/Windows/Start Menu/Programs')); foreach($location in $locations){$shortcut=$shell.CreateShortcut((Join-Path $location 'Caliber Scanner.lnk')); $shortcut.TargetPath=Join-Path $env:WINDIR 'System32/wscript.exe'; $shortcut.Arguments='"'+${quote(launcher)}+'"'; $shortcut.WorkingDirectory=${quote(target)}; $shortcut.Description='Start the Caliber local scanner connector'; $shortcut.Save()}`;
try{await promisify(execFile)(powershell,['-NoProfile','-NonInteractive','-Command',command],{windowsHide:true});}catch{console.log('Could not create shortcuts. Use Start-Caliber-Scanner.cmd in '+target);}
try{const result=await promisify(execFile)(path.join(target,'node.exe'),[path.join(target,'start.mjs')],{cwd:target,windowsHide:true});console.log(result.stdout);}catch(error){console.log(error.stderr||'Finish scanning, restart Windows and open the updated Caliber Scanner shortcut.');}
console.log('Installed. Open https://pulse-ll.cmll.in, sign in, then click Connect PC scanner.');
console.log('After restarting Windows, double-click the Caliber Scanner shortcut before connecting from MIS.');

@echo off
cd /d "%~dp0"
"%~dp0node.exe" "%~dp0start.mjs"

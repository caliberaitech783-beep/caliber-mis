import {spawn} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
let running=false;try{const r=await fetch('http://127.0.0.1:4174/api/health',{signal:AbortSignal.timeout(2000)});const health=await r.json();if(health.service==='caliber-scanner'&&health.version!=='1.0.1')throw Error('An older Caliber Scanner is running. Finish scanning, restart Windows, then open the updated Caliber Scanner shortcut.');if(r.ok&&(health.service==='caliber-scanner'||health.database==='connected'))running=true;else throw Error('Port 4174 is being used by another program.');}catch(error){if(error.message.includes('another program')||error.message.includes('older Caliber Scanner')){console.error(error.message);process.exit(1);}}
if(!running){const child=spawn(process.execPath,[path.join(root,'connector.mjs')],{cwd:root,windowsHide:true,detached:true,stdio:'ignore'});child.unref();}
for(let n=0;n<20;n++){try{const r=await fetch('http://127.0.0.1:4174/api/health',{signal:AbortSignal.timeout(1000)});if(r.ok){console.log('Caliber Scanner is ready. Click Connect PC scanner in online MIS.');process.exit(0);}}catch{}await new Promise(resolve=>setTimeout(resolve,500));}
console.error('Connector did not start. Check that port 4174 is available.');process.exitCode=1;

import fs from 'node:fs/promises';
import path from 'node:path';
export async function copyConnectorFiles(source,target){
 // fs.cp(errorOnExist:true) requires the destination itself to be absent.
 await fs.mkdir(path.dirname(target),{recursive:true});
 await fs.cp(source,target,{recursive:true,errorOnExist:true,force:false});
}

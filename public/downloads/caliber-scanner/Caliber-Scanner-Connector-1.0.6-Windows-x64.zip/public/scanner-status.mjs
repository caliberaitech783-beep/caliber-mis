const ONLINE='https://pulse-ll.cmll.in',params=new URLSearchParams(location.hash.slice(1));
const nonce=params.get('nonce'),kind=params.get('kind'),ticket=params.get('ticket');
const valid=parent!==window&&/^[a-f0-9-]{36}$/i.test(nonce||'')&&/^[a-f0-9]{64}$/i.test(ticket||'')&&['vehicle','equipment'].includes(kind);
let token='',active=true,timer,busy=false;
const send=data=>{if(active)parent.postMessage({type:'scanner-status',nonce,...data},ONLINE)};
async function api(route,body){const response=await fetch('/api/'+route,{method:body?'POST':'GET',headers:{'X-Caliber-Scanner':'1',Authorization:'Bearer '+token,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{})});const data=await response.json();if(!response.ok)throw Object.assign(Error(data.error||'Scanner status unavailable'),{status:response.status});return data}
async function report(){if(!active||busy)return;busy=true;try{const [health,status]=await Promise.all([api('health'),api('local-scanner/status')]);send({version:health.version,devices:status.devices.map(d=>({id:d.id,name:d.name})),deviceError:status.deviceError||'',connected:true})}catch(error){send({connected:false,error:error.message,expired:error.status===401});if(error.status===401)clearInterval(timer)}finally{busy=false}}
if(valid)void(async()=>{try{token=(await api('scanner-connector/connect',{nonce,kind,ticket})).token;history.replaceState(null,'',location.pathname);await report();if(active)timer=setInterval(report,5000)}catch(error){send({connected:false,error:error.message,expired:error.status===401})}})();
window.addEventListener('pagehide',()=>{active=false;clearInterval(timer)},{once:true});

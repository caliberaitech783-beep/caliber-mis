export function organizationScanners(devices=[]){
 return devices.filter(device=>{
  if(!device||typeof device.id!=='string'||!device.id.trim())return false;
  const label=String(device.name||'');
  const name=label.toLowerCase().replace(/[^a-z0-9]/g,'');
  return /\bads[\s-]*3100(?!\d)/i.test(label)||/canon.*drc225(?:ii|2)(?!i|[0-9])/.test(name)||/canon.*drc225usb[0-9]*$/.test(name);
 });
}
export function chooseConnectedScanner(devices=[],current='',previousIds){
 const supported=organizationScanners(devices);
 if(supported.some(device=>device.id===current))return current;
 const added=previousIds?supported.filter(device=>!previousIds.includes(device.id)):[];
 return (added.length===1?added[0]:supported[0])?.id||'';
}
export function scannerConnectionMessage(devices=[],selected=''){
 const supported=organizationScanners(devices),device=supported.find(device=>device.id===selected);
 if(!supported.length)return 'No compatible Windows scanner detected. Check power and the USB cable, then test the scanner in Windows Scan or Brother ScanEssentials. If Windows cannot find it, install the official Brother ADS-3100 Full Driver & Software Package with USB selected. Reopen Caliber Scanner and refresh scanners.';
 return `${device?.name||supported[0].name} connected. ${supported.length>1?'Both organization scanners are detected; choose the scanner to use. ':''}Load the feeder, then click Scan.`;
}

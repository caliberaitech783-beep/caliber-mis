import {copyConnectorFiles} from './install-files.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createInterface} from 'node:readline/promises';
import {execFile,spawn} from 'node:child_process';
import {promisify} from 'node:util';
const root=path.dirname(fileURLToPath(import.meta.url));
if(process.platform!=='win32'||process.arch!=='x64')throw Error('This installer requires 64-bit Windows.');
const base=path.join(process.env.LOCALAPPDATA,'CaliberScanner'),stamp=new Date().toISOString().replace(/[:.]/g,'-'),target=path.join(base,'versions','1.0.6-'+stamp);
console.log('Install Caliber Scanner for Brother ADS-3100 and Canon DR-C225II.');
console.log('Files: '+target+'\nCreates or updates Caliber Scanner shortcuts on your Desktop, Start Menu and Windows Startup folder. Starts automatically when this Windows user signs in after a restart. Starts a connector accessible only on this PC at 127.0.0.1:4174.');
console.log('No administrator account, local MIS database, or separate Node.js installation is required. Scanner drivers must be installed separately.');
const prompt=createInterface({input:process.stdin,output:process.stdout});const answer=await prompt.question('Install and start? Type YES: ');prompt.close();if(answer.trim().toUpperCase()!=='YES'){console.log('Installation cancelled; no changes made.');process.exit(0);}
console.log('[1/5] Copying connector files into the permanent installation folder...');
await copyConnectorFiles(root,target);
console.log('[1/5] Files copied.');
console.log('[2/5] Preparing the background launcher...');
const launcher=path.join(target,'Launch-Caliber-Scanner.vbs');
await fs.writeFile(launcher,'Set shell = CreateObject("WScript.Shell")\r\nshell.Run """'+path.join(target,'node.exe').replaceAll('"','""')+'"" ""'+path.join(target,'start.mjs').replaceAll('"','""')+'""", 0, False\r\n');
console.log('[2/5] Background launcher prepared.');
console.log('[3/5] Registering automatic startup and scanner shortcuts...');
const quote=s=>"'"+s.replaceAll("'","''")+"'";
const powershell=path.join(process.env.SystemRoot,'System32','WindowsPowerShell','v1.0','powershell.exe');
const command=`$ErrorActionPreference='Stop'; $shell=New-Object -ComObject WScript.Shell; $locations=@($shell.SpecialFolders.Item('Startup'),$shell.SpecialFolders.Item('Desktop'),(Join-Path $env:APPDATA 'Microsoft/Windows/Start Menu/Programs')); foreach($location in $locations){$shortcut=$shell.CreateShortcut((Join-Path $location 'Caliber Scanner.lnk')); $shortcut.TargetPath=Join-Path $env:WINDIR 'System32/wscript.exe'; $shortcut.Arguments='"'+${quote(launcher)}+'"'; $shortcut.WorkingDirectory=${quote(target)}; $shortcut.Description='Start Caliber Scanner automatically at Windows sign-in'; $shortcut.WindowStyle=7; $shortcut.Save(); if(!(Test-Path -LiteralPath (Join-Path $location 'Caliber Scanner.lnk'))){throw 'Scanner startup shortcut could not be verified'}}`;
try{await promisify(execFile)(powershell,['-NoProfile','-NonInteractive','-Command',command],{windowsHide:true});}catch{throw Error('Automatic startup could not be installed. Windows did not allow the Caliber Scanner shortcuts to be created. Contact your Windows administrator before retrying.');}
console.log('[3/5] Automatic startup registered and verified.');
console.log('[4/5] Starting the connector and checking its health...');
let running=false;
try{const result=await promisify(execFile)(path.join(target,'node.exe'),[path.join(target,'start.mjs')],{cwd:target,windowsHide:true});console.log(result.stdout);running=true;}catch(error){console.log(error.stderr||'Finish scanning, restart Windows once and sign in to activate the updated connector.');}
console.log(running?'[4/5] Connector is running.':'[4/5] Installation saved; restart Windows once to activate this version.');
console.log(running?'[5/5] Setup complete. Return to MIS; scanner status will update automatically.':'[5/5] Automatic startup is ready. After restarting Windows, return to MIS and select Check this PC.');
console.log('Installed. Open https://pulse-ll.cmll.in, sign in, then click Connect PC scanner.');
console.log('Automatic startup is installed for this Windows user. After future restarts, sign in to Windows and connect from MIS. You do not need to reinstall or open the shortcut each time.');
